@extends('usuario.principa_usul')
@section('content')
<div class="alert text-center titulo" role="alert">
 <h4>Tabla de reconocimientos obtenidos</h4>
</div>
<div class="row letraform">
 <div class="col-md-12 table-responsive">
  <table class="table">
  <thead class="colortablas">
    <tr>
      <th scope="col">No</th>
      <th scope="col">Nombres</th>
      <th scope="col">Apellidos</th>
      @foreach($categoria as $cat)
      <th scope="col">{{$cat->descripcion}}</th>
      @endforeach
      <th scope="col">Total</th>
    </tr>
  </thead>
  <tbody>
    <?php
      $contador = 0;
    ?>
  @foreach ($recibidos as $conjuntoUsuarios)
  @if (!empty($conjuntoUsuarios))
      @foreach ($conjuntoUsuarios as $usuario)
       <tr>
          <th scope="row">{{ $contador+=1 }}</th>
          <td>{{ $usuario->nombre }}</td>
          <td>{{ $usuario->ape }}</td>
          @foreach($categoria as $cate)
             <td>{{ $usuario->{'c' . $cate->id} ?? 0 }} |  @if($usuario->tot != 0) {{round($usuario->{'c' . $cate->id}*100/$usuario->tot, 1)}}% @else 0%  @endif</td>
          @endforeach
          <td>{{ $usuario->tot ?? 0 }} | @if($usuario->tot != 0) 100% @else 0% @endif</td>
       </tr>
        @endforeach
    @endif
   @endforeach
   </tbody>
    </table>  
 </div>
</div>
<!---=============== segunda sección ===============-->
<div class="alert text-center titulo" role="alert">
 <h4>Tabla de insignias obtenidas</h4>
</div>
<div class="row letraform">
 <div class="col-md-12 table-responsive">
 <table class="table">
    <thead class="colortablas">
        <tr>
            <th scope="col">No</th>
            <th scope="col">Nombres</th>
            <th scope="col">Apellidos</th>
            <th scope="col">Oro</th>
            <th scope="col">Plata</th>
            <th scope="col">Bronce</th>
            <th scope="col">Total</th>
        </tr>
    </thead>
    <tbody>
        @foreach($users as $index => $usu)
        <?php 
            $oroCount = 0;
            $plataCount = 0;
            $bronceCount = 0;
            $totalsum = 0;
        ?>
        <tr>
            <td>{{ $index + 1 }}</td>
            <td>{{ $usu->name }}</td>
            <td>{{ $usu->apellido }}</td>
            @if(!empty($insignias))
            @foreach($insignias as $cant)
                @if($usu->id == $cant->id_usuario)
                    @if($cant->des == "Oro")
                        <?php $oroCount++; ?>
                    @elseif($cant->des == "Plata")
                        <?php $plataCount++; ?>
                    @elseif($cant->des == "Bronce")
                        <?php $bronceCount++; ?>
                    @endif
                    <?php $totalsum = $oroCount + $plataCount + $bronceCount;  ?>
                @endif
            @endforeach
            @endif
            <td>{{ $oroCount }} | @if($totalsum != 0){{ $oroCount*100/$totalsum }}% @else 0% @endif</td>
            <td>{{ $plataCount }} | @if($totalsum != 0){{ $plataCount*100/$totalsum }}% @else 0% @endif</td>
            <td>{{ $bronceCount }} | @if($totalsum != 0){{ $bronceCount*100/$totalsum }}%  @else 0% @endif</td>
            <td>{{ $totalsum }} |  @if($totalsum != 0) 100% @else 0% @endif</td>
        </tr>
        @endforeach
    </tbody>
</table>
 </div>
</div>
@endsection