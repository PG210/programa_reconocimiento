<?php

namespace App\Models\RecibeCatMoldel;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RecibirCat extends Model
{
    protected $table = 'catrecibida';
    protected $primaryKey = 'id';
}
