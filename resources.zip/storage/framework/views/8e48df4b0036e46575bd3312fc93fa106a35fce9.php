<?php
  use Illuminate\Support\Facades\DB;

  $es = DB::table('estavotacion')->where('estado', '=', 1)->select('estado')->get();

?>
<nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column nav-flat nav-child-indent" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="<?php echo e(route('inicio')); ?>" class="nav-link <?php if(Request::is('inicio')): ?> active <?php endif; ?>">
            <i class="nav-icon fas fa-home"></i>
            <p>
              Inicio
            </p>
                </a>
          </li> 
          
          <li class="nav-header">Metricas</li>
         
          
   
          <li class="nav-item">
            <a href="/gerente/informe/1" class="nav-link <?php if(Request::is('gerente/informe/1')): ?> active <?php endif; ?>">
            <i class="nav-icon fas fa-medal"></i>
              <p>
                Recompensas
              </p>
             </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('visinsignias')); ?>" class="nav-link <?php if(Request::is('reporte/visualizar/recompensas')): ?> active <?php endif; ?>">
              <i class="nav-icon fas fa-trophy"></i>
              <p>
              Insignias a Obtener
              </p>
            </a>
          </li>
          <?php if(isset($es[0]->estado)): ?>
          <?php if($es[0]->estado==1): ?>
          <li class="nav-item">
            <a href="<?php echo e(route('votacion_user')); ?>"  class="nav-link <?php if(Request::is('vista/votacion')): ?> active <?php endif; ?>">
            <i class="nav-icon fas fa-vote-yea"></i>
              <p>
                Votación
              </p>
            </a>
          </li>
          <?php endif; ?>
          <?php endif; ?>

          <li class="nav-header">Configuración</li>
          
          <li class="nav-item">
            <a href="<?php echo e(route('perfil')); ?>"  class="nav-link <?php if(Request::is('perfil')): ?> active <?php endif; ?>">
            <i class="nav-icon fas fa-user-cog"></i>
             <p>
                Perfil 
              </p>
            </a>
          </li>
        <!-- <li class="nav-header">EXAMPLES</li>
    
          <li class="nav-header">MISCELLANEOUS</li>-->
          
        </ul>
      </nav><?php /**PATH C:\xampp\htdocs\Evolucion_reconoser_024\resources\views/gerente/menugerente.blade.php ENDPATH**/ ?>