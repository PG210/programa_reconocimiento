<?php
  use Illuminate\Support\Facades\DB;

  $es = DB::table('estavotacion')->where('estado', '=', 1)->select('estado')->get();

?>
<nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column nav-flat nav-child-indent" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="<?php echo e(route('inicio')); ?>" class="nav-link <?php if(Request::is('inicio')): ?> active <?php endif; ?>">
              <i class="nav-icon fas fa-home"></i> 
              <p>
                Inicio
              </p>
            </a>
          </li>    
          <li class="nav-header">Reconocimientos</li>
          <!-- ========================================================-->
          <!--=================-->
          <li class="nav-item">
            <a href="<?php echo e(route('listareconocer')); ?>" class="nav-link <?php if(Request::is('reconocimientos/usuario')): ?> active ver <?php endif; ?>">
              <i class="nav-icon fa fa-paper-plane"></i>
              <p>
                Enviar reconocimiento
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('reporteinsignias')); ?>" class="nav-link <?php if(Request::is('reporte/insignias')): ?> active <?php endif; ?>">
              <i class="nav-icon fas fa-trophy"></i>
              <p>
                Mis reconocimientos
              </p>
            </a>
          </li>
          
          <li class="nav-header">Votaciones</li>
          <!---===========-->
          <li class="nav-item">
            <a href="<?php echo e(route('habilitar_votacion')); ?>" class="nav-link <?php if(Request::is('admin/votacion')): ?> active <?php endif; ?>">
            <i class="nav-icon fas fa-tasks"></i>
              <p>
               Control de votaciones
              </p>
            </a>
          </li>
          <?php if(isset($es[0]->estado)): ?>
          <?php if($es[0]->estado==1): ?>
          <li class="nav-item">
            <a href="<?php echo e(route('votacion_user')); ?>" class="nav-link <?php if(Request::is('vista/votacion')): ?> active <?php endif; ?>">
            <i class="nav-icon fas fa-vote-yea"></i>
              <p>
               Participar en votación
              </p>
            </a>
          </li>
          <?php endif; ?>
          <?php endif; ?>

          <li class="nav-header">Administración</li>
          <li class="nav-item">
            <a href="<?php echo e(route('recompensas_obtenidas')); ?>" class="nav-link <?php if(Request::is('reporte/recompensas')): ?> active <?php endif; ?>">
            <i class="nav-icon fas fa-hand-holding-heart"></i>
              <p>
              Recompensas
              </p>
             </a>
          </li>
          
          <!--==============--> 
            <!--===================metricas ============================= -->
            <li class="nav-item">
            <a href="#" class="nav-link ">
            <i class="nav-icon ion-stats-bars"></i>
              <p>
               Métricas
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('metricasranking')); ?>" class="nav-link <?php if(Request::is('metricas/ranking')): ?> active <?php endif; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Rec. Obtenidos</p>
                </a>
              </li>
              <li class="nav-item">
               <a href="<?php echo e(route('metricasEnvio')); ?>" class="nav-link <?php if(Request::is('reconocimientos/enviados/admin')): ?> active <?php endif; ?>">
                 <i class="nav-icon far fa-circle"></i>
                 <p>Rec. Enviados </p>
               </a>
             </li>  
            </ul>
          </li>
          <li class="nav-header">Configuración</li>
          <li class="nav-item">
            <a href="<?php echo e(route('perfil')); ?>" class="nav-link <?php if(Request::is('perfil')): ?> active <?php endif; ?>">
              <i class="nav-icon ion-ios-body-outline"></i>
              <p>
                Mi perfil
              </p>
            </a>
          </li>
        </ul>
      </nav><?php /**PATH C:\xampp\htdocs\Evolucion_reconoser_024\resources\views/jefe/menujefe.blade.php ENDPATH**/ ?>