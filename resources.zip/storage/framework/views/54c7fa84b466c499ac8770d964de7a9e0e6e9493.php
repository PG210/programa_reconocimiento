
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container">
    <div class="row mb-2">
      <div class="col-sm-8">
      <h1 class="m-0">Gestión de grupos:</h1>
      </div>
      <!-- /.col -->
      <div class="col-sm-4">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Inicio</a></li>
          <li class="breadcrumb-item active">Gestión de grupos</li>
        </ol>
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</div>

<div class="container">
<div class="row mb-2">
  <div class="col-12">
  <div class="card">

                    <div class="card-body">
   <!--tabla para ver los valores-->
   <?php if(Session::has('exito')): ?>
        <div id="exito-alert" class="alert alert-info alert-dismissible fade show letraform" role="alert">
        <strong><?php echo e(Session::get('exito')); ?></strong> 
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
    <div id="exito-alert" class="alert alert-danger alert-dismissible fade show letraform" role="alert">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><strong><?php echo e($error); ?></strong></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
           </button>
        </div>
    <?php endif; ?>
    <!---carga-->
        <!-- Button trigger modal -->
       
        <!--=================== botones==========================-->
        <div class="btn-group" role="group" aria-label="Basic outlined example">
            <button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#carga">
            <i class="fas fa-user-plus"></i> Grupos
            </button>
        </div>
        <!--=======================================================-->
       
        <!-- Modal -->
        <form action="<?php echo e(route('nuevoGrupo')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="carga" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header titulo">
                <h5 class="modal-title" id="exampleModalLabel">Registrar nuevo grupo</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body letraform">
              <p class="">Crea un nuevo grupo y configura sus detalles.</p>
               <!--formulario-->
               <div class="form-group col-md-12">
                    <div class="custom-file">
                    <label class="m-0" for="descrip">Nombre</label>
              <p class="m-0">Ingresa el nombre del grupo.</p>
                        <input type="text" class="form-control" name="grupo" id="grupo" placeholder="Nuevo grupo" accept="text" required>
                        
                    </div>
                 </div>
               <!--formulario de carga-->
            </div>
            <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default salir" data-dismiss="modal">Salir</button>
            <button type="submit" class="btn btn-success confirmar">Registrar</button>
                
            </div>
            </div>
        </div>
        </div>
        </form>
        
    <!--carga masiva-->
    <br>
    <div class="table-responsive">
    <table class="table table-hover table-estadisticas" >
              <thead class="tablaheader letraform">
              <tr>
                <th scope="col" style="witdh: 50px !important;" class="text-center">Idgrupo</th>
                <th scope="col">Nombre</th>
                <th scope="col">No. Usuarios</th>
                <th scope="col" style="witdh: 100px !important;" class="text-center">Acciones</th>
              </tr>
            </thead>
            <tbody class="letraform">
               <?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td style="witdh: 50px !important;" class="text-center"><?php echo e($grup->id); ?></td>
                    <td><?php echo e($grup->descripcion); ?></td>
                    <td>
                      <?php $__currentLoopData = $tot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($grup->id == $t->idgrupo): ?>
                        <?php echo e($t->totusu); ?>

                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td style="witdh: 100px !important;" class="text-center">
                    <div class="btn-group" role="group" aria-label="Basic outlined example">
                        <a href="<?php echo e(route('metricas', $grup->id)); ?>" type="button" class="btn btn-outline-info btn-sm"><i class="fas fa-chart-line"></i></a>
                        <button type="button" class="btn btn-outline-primary btn-sm" data-toggle="modal" data-target="#editarGrupo<?php echo e($grup->id); ?>"><i class="fas fa-edit"></i></button>
                        <button type="button" class="btn btn-outline-success btn-sm" data-toggle="modal" data-target="#listaUsers<?php echo e($grup->id); ?>"><i class="fas fa-users"></i></button>
                        <button type="button" class="btn btn-outline-danger btn-sm" data-toggle="modal" data-target="#eliminarGrupo<?php echo e($grup->id); ?>"><i class="fas fa-trash-alt"></i></button>
                    </div>
                    <!--========================================-->
                       <!--=============== usuarios ==============-->
                       <div class="modal fade" id="listaUsers<?php echo e($grup->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg modal-dialog-scrollable">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title letraform" id="exampleModalLabel">Agregar colaboradores al grupo: <?php echo e($grup->descripcion); ?></h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body letraform">
                              <!--listado de usuarios-->
                              <div class="row">
                                <div class="col-12 text-end">
                                    <input type="text" class="form-control" id="searchTerm" onkeyup="doSearch()" placeholder="Buscar...">
                                </div>
                              </div>
                              <!--================================-->
                             <form action="<?php echo e(route('grupUser', $grup->id)); ?>" method="POST">
                               <?php echo csrf_field(); ?>
                              <div class="table-responsive">
                              <table class="table-hover table-estadisticas" id="tablaDate">
                                <thead>
                                  <tr>
                                    <th></th>
                                    <th>Nombres</th>
                                    <th>Correo</th>
                                    <th>Rol</th>
                                    <th>imagen</th>
                                  </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr> 
                                    <td>
                                     
                                        <input type="checkbox" name="checkUsuarios[]" value="<?php echo e($user->id); ?>" aria-label="Checkbox for following text input" <?php $__currentLoopData = $usugrupo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($user->id == $usug->idusu && $grup->id == $usug->idgrupo): ?> checked <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                     
                                    </td>
                                    <td><?php echo e($user->name); ?> <?php echo e($user->apellido); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->rol); ?></td>
                                    <td>
                                    <div class="user-panel mt-0 pb-0 mb-0 d-flex">
                                      <div class="image">
                                        <?php if($user->imagen!=null && $user->imagen != 'ruta'): ?>
                                          <img src="<?php echo e(asset('dist/imgperfil/'.$user->imagen)); ?>" class="img-circle elevation-1" alt="User Image" style="padding-bottom:2px;">
                                        <?php endif; ?>
                                        <?php if($user->imagen==null || $user->imagen == 'ruta'): ?>
                                        <img src="<?php echo e(asset('dist/imgperfil/perfil_no_borrar.jpeg')); ?>" class="img-circle elevation-1" alt="User Image" style="padding-bottom:2px;" >
                                        <?php endif; ?>
                                        </div>
                                      </div>
                                    </td>
                                  </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <tr class='noSearch hide'>
                                    <td colspan="3"></td>
                                  </tr>
                                </tbody>
                              </table>
                              </div>
                              <!--lista users-->
                            </div>
                             <div class="modal-footer justify-content-between">
                                
                                <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fas fa-sign-out-alt"></i> Salir</button>
                                <button type="submit" class="btn btn-success">Guardar</button>  
                              </div>
                              </form>
                          </div>
                        </div>
                      </div>
                        <!-- ============Modal ========== -->
                        <div class="modal fade" id="editarGrupo<?php echo e($grup->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Editar Información del Grupo</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form action="<?php echo e(route('actuGrupo')); ?>" method="POST">
                             <?php echo csrf_field(); ?>
                            <div class="modal-body text-left">
                              <p>Modifica los detalles de este grupo para mantenerlo actualizado.</p>
                                <!---==========-->
                                    <div class="form-group">
                                        <label for="descrip" class="col-form-label">Nombre</label>
                                        <textarea class="form-control" id="descrip" name="descrip"><?php echo e($grup->descripcion); ?></textarea>
                                        <input type="number" id="idgrupo" name="idgrupo" value="<?php echo e($grup->id); ?>" hidden>
                                    </div>
                                <!--========-->
                            </div>
                            <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Salir</button>
                            <button type="submit" class="btn btn-success">Actualizar</button>
                                
                            </div>
                            </form>
                            </div>
                        </div>
                        </div>
                    <!--==========================-->
                    <div class="modal fade" id="eliminarGrupo<?php echo e($grup->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Mensaje de confirmación</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body text-left">
                               <p>
                               ¿Estás seguro de que deseas eliminar el grupo "<?php echo e($grup->descripcion); ?>"?
                               </p>
                            </div>
                            <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                            <form action="<?php echo e(route('deleteGrupo', $grup->id)); ?>" method="POST">
                                  <?php echo csrf_field(); ?>
                                  <button type="submit" class="btn btn-success">Eliminar</button>
                              </form>
                            
                              
                                
                            </div>
                            </div>
                        </div>
                    </div>
                    <!--========================================-->
                    </td>
                  </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
      </div>
        <!--end tabla-->
        </div>
        </div>
        </div>
        </div>
        </div>
<script src="<?php echo e(asset('js/buscador.js')); ?>"></script>
<script>
    setTimeout(function() {
        $('#exito-alert').alert('close');
    }, 4000);

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('usuario.principa_usul', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Evolucion_reconoser_024\resources\views/grupos/principal.blade.php ENDPATH**/ ?>