
<?php $__env->startSection('content'); ?>
<main role="main" class="container my-5 letrap forms">
    <div class="row">
       <div class="col-lg-12 col-md-12 col-12 text-center">
          <h4 class="my-5">Error 404: Página no encontrada</h4>
          <p>Lo sentimos, la página que estás buscando no existe.</p>
       </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Evolucion_reconoser_024\resources\views/errors/404.blade.php ENDPATH**/ ?>