
<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container">
    <div class="row mb-2">
      <div class="col-sm-8">
      <h1 class="m-0">Métricas del grupo: <?php echo e($grupo->descripcion); ?> </h1>
      <p class="m-0">Seguimiento del desempeño y participación de los colaboradores en el grupo.</p>
      </div>
      <!-- /.col -->
      <div class="col-sm-4">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Inicio</a></li>
          <li class="breadcrumb-item active">Métricas del grupo</li>
        </ol>
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</div>

<div class="container">

<div class="row">
		<div class="col-lg-3 col-12">
			<div class="row">
        <div class="col-12">
					<!-- small box -->
					<div class="small-box bg-success">
						<div class="inner">
              <!--primer valor-->
              <?php if($cate->first()): ?>
                <?php
                    //validar la division por cero y limitar el porcentaje al 100 por ciento, tambien el valor 2000 debe ser ajustable en categorias
                    $widbarra = min(100, ($cate->first()->ptotal * 100) / max(2000, 1));
                ?>
                <p class="m-0">Categoría más activa:</p>
                <p class="m-0">" <?php echo e($cate->first()->nomcat); ?> " con</p>
                <h5><?php echo e($cate->first()->ptotal); ?> Puntos</h5>
                <div class="progress-group">
                  Avance
                  <span class="float-right"><b> <?php echo e($cate->first()->ptotal); ?>  | <?php echo e($widbarra); ?>% </b></span>
                  <div class="progress progress-sm">
                  <div class="progress-bar bg-warning" style="width: <?php echo e($widbarra); ?>% "></div>
                  </div>
                </div> 
              <?php else: ?>
                <p class="m-0">Aún no hay una categoría destacada.</p>
              <?php endif; ?>          
        </div>
        <div class="icon">
          <i class="ion ion-stats-bars"></i>
        </div>
        <a href="#" class="small-box-footer"> <i class="fas fa-arrow-circle-right"></i></a>
        </div>
      </div>
			<!-- ./col -->
      <div class="col-12">
				<!-- small box -->
					<div class="small-box bg-danger">
						<div class="inner">
            <?php if($cate->last()): ?>
              <?php
                  //validar la division por cero y limitar el porcentaje al 100 por ciento, tambien el valor 2000 debe ser ajustable en categorias
                  $minbarra = min(100, ($cate->last()->ptotal * 100) / max(2000, 1));
              ?>
              <p class="m-0">Categoría menos reconocida:</p>
              <p class="m-0">"<?php echo e($cate->last()->nomcat); ?>" con</p>
							<h5><?php echo e($cate->last()->ptotal); ?> Puntos</h5>
              <div class="progress-group">
								Avance
                <span class="float-right"><b><?php echo e($cate->last()->ptotal); ?> |  <?php echo e($minbarra); ?>% </b></span>
                <div class="progress progress-sm">
                  <div class="progress-bar bg-warning" style="width: <?php echo e($minbarra); ?>% "></div>
                </div>
               </div>
            <?php else: ?>
               <p class="m-0">Aún no hay una categoría menos reconocida.</p>
            <?php endif; ?> 
						</div>
						<div class="icon">
							<i class="ion ion-stats-bars"></i>
						</div>
						<a href="#" class="small-box-footer"><i class="fas fa-arrow-circle-right"></i></a>
					</div>
				</div>
				<!-- ./col -->
				<div class="col-12">
					<!-- small box -->
					<div class="small-box bg-warning">
						<div class="inner">
            <?php if(isset($usupuntos)): ?>
							<p class="m-0">Top Colaborador:  </p>
							<h5><?php echo e($usupuntos->nomusu); ?> <?php echo e($usupuntos->apeusu); ?></h5>
							<p class="m-0">con <?php echo e($usupuntos->ptotal); ?> puntos</p>
						</div>
						<div class="icon">
							<i class="ion ion-person-add"></i>
						</div>
            <a href="#" class="small-box-footer">¡Felicítalo! <i class="fas fa-arrow-circle-right"></i></a>
            <?php else: ?>
              <p class="m-0">Aún no hay un colaborador destacado.</p>
            <?php endif; ?>
						
					</div>
				</div>
				<!-- ./col -->
			</div>
			<!-- /.row -->
		</div>
		<div class="col-lg-9 col-12">
			<!-- Gráficos -->
			<div class="row">
				<div class="col-md-6">
					<div class="card card-primary">
						<div class="card-header">
							<h3 class="card-title">Línea de Tiempo:</h3>

							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse">
                      <i class="fas fa-minus"></i>
                    </button>
								<button type="button" class="btn btn-tool" data-card-widget="remove">
                      <i class="fas fa-times"></i>
                    </button>
							</div>
						</div>
						<div class="card-body">
							<p>La evolución de los puntos del grupo en el tiempo.</p>
							<div class="chart-container">
								<canvas id="trendChart"></canvas>
							</div>
						</div>
						<!-- /.card-body -->
					</div>

				</div>
				<div class="col-md-6">

					<div class="card card-primary">
						<div class="card-header">
							<h3 class="card-title">¿Dónde brilla más tu equipo?:</h3>

							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse">
                      <i class="fas fa-minus"></i>
                    </button>
								<button type="button" class="btn btn-tool" data-card-widget="remove">
                      <i class="fas fa-times"></i>
                    </button>
							</div>
						</div>
						<div class="card-body">
							<p>Comparación del total de puntos de cada categoría.</p>

							<div class="chart-container">
								<canvas id="categoryChart-grupo"></canvas>
							</div>
						</div>
						<!-- /.card-body -->
					</div>
				</div>
				
			</div>
            <div class="row">
  <div class="col-12">
  <div class="card">

                    <div class="card-body">
   <!--tabla para ver los valores-->
   <?php if(Session::has('exito')): ?>
        <div id="exito-alert" class="alert alert-info alert-dismissible fade show letraform" role="alert">
        <strong><?php echo e(Session::get('exito')); ?></strong> 
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
    <?php endif; ?>
   <div class="container mt-5 letraform">
   <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            //validar la division por cero y limitar el porcentaje al 100 por ciento, tambien el valor 2000 debe ser ajustable en categorias
            $anchoBarra = min(100, ($cat->ptotal * 100) / max(2000, 1));
        ?>
        <li class="mt-2">Categoría: <?php echo e($cat->nomcat); ?>, Total de puntos: <?php echo e($cat->ptotal); ?></li>
        <div class="progress mt-2">
            <div class="progress-bar bg-success" style="width: <?php echo e(number_format($anchoBarra, 2)); ?>%">
                <?php echo e(number_format($anchoBarra, 1)); ?> %
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="row table-responsive letraform">
    <!---tabla mejorada --->
    <table class="table table-hover table-estadisticas">
        <thead>
            <tr>
                <th scope="col">Colaborador</th>
                <th scope="col">Categoría</th>
                <th scope="col">Puntaje Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $usuario_actual = null; ?>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php if($usuario_actual !== $dato['idusu']): ?>
                        <td rowspan="<?php echo e(collect($datos)->where('idusu', $dato['idusu'])->count()); ?>">
                            <?php echo e($dato['nomusu']); ?> <?php echo e($dato['apeusu']); ?>

                        </td>
                        <?php $usuario_actual = $dato['idusu']; ?>
                    <?php endif; ?>
                    <td><?php echo e($dato['nomcat']); ?></td>
                    <td><?php echo e($dato['ptotal']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <!--=======end tabla==========--->
    </div>
     
    </div>
   </div>
   </div>
   </div>
   </div>

		</div>
		<!-- /.row -->
	</div>


   </div>
   </div>
<!--end tabla-->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  window.recmes = <?php echo json_encode($ptime, 15, 512) ?>;
  window.totcat = <?php echo json_encode($pcat, 15, 512) ?>;
  window.label2 = "Cantidad de puntos";
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('usuario.principa_usul', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Evolucion_reconoser_024\resources\views/grupos/metricas.blade.php ENDPATH**/ ?>