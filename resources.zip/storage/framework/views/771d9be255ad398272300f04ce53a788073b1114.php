<!-- Google Font: Source Sans Pro -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
<!-- Font Awesome listo-->
<link rel="stylesheet" href="<?php echo e(asset('plugins/fontawesome-free/css/all.min.css')); ?>">
<!-- Ionicons -->
<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
<!-- Tempusdominus Bootstrap 4  listo-->
<link rel="stylesheet" href="<?php echo e(asset('plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css')); ?>">
<!-- iCheck listo-->
<link rel="stylesheet" href="<?php echo e(asset('plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
<!-- Theme style listo-->
<link rel="stylesheet" href="<?php echo e(asset('dist/css/adminlte.min.css')); ?>">
<!-- Theme style listo-->
<link rel="stylesheet" href="<?php echo e(asset('dist/css/r.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/actual-reconoser.css')); ?>">
<!-- overlayScrollbars listo-->
<link rel="stylesheet" href="<?php echo e(asset('plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
<!-- Daterange picker listo-->
<link rel="stylesheet" href="<?php echo e(asset('plugins/daterangepicker/daterangepicker.css')); ?>">
<!-- summernote listo listo-->
<link rel="stylesheet" href="<?php echo e(asset('plugins/summernote/summernote-bs4.min.css')); ?>">

<!--manejar los mensajes-->
<link rel="stylesheet" href=" <?php echo e(asset('dist/css/toastr.min.css')); ?>">
<!--============ para el recorrido -->
<link rel="stylesheet" href="<?php echo e(asset('dist/css/introjs.min.css')); ?>">

<?php /**PATH C:\xampp\htdocs\Evolucion_reconoser_024\resources\views/usuario/stylecss.blade.php ENDPATH**/ ?>