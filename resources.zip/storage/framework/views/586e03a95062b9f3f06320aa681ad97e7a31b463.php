
<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container">
    <div class="row mb-2">
      <div class="col-sm-8">
      <h1 class="m-0">Actualizar usuario:</h1>
        <h5  class="m-0"><?php echo e($dat[0]->name); ?> <?php echo e($dat[0]->apellido); ?></h5>
      </div>
      <!-- /.col -->
      <div class="col-sm-4">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Inicio</a></li>
          <li class="breadcrumb-item active">Actualizar usuario</li>
        </ol>
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</div>

<div class="container">
<div class="row mb-2">
  <div class="col-12">
  <div class="card">

                    <div class="card-body">
<?php if(Session::has('mensaje')): ?>
        <br>
        <div class="alert alert-info alert-dismissible fade show letraform" role="alert">
        <strong><?php echo e(Session::get('mensaje')); ?></strong> 
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
        <br>
<?php endif; ?>
<?php if(Session::has('menerror')): ?>
        <br>
        <div class="alert alert-danger alert-dismissible fade show letraform" role="alert">
        <strong><?php echo e(Session::get('menerror')); ?></strong> 
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
        <br>
<?php endif; ?>
<form action="<?php echo e(route('actudatos')); ?>" method="POST" class="letraform">
<?php echo csrf_field(); ?>
<div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Nombre</label>
      <input type="text" class="form-control" id="inputEmail4" name="nombre" value="<?php echo e($dat[0]->name); ?>">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Apellido</label>
      <input type="text" class="form-control" id="inputPassword4"  name="apellido" value="<?php echo e($dat[0]->apellido); ?>">
    </div>
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Dirección</label>
      <input type="text" class="form-control" id="inputEmail4"name="direccion" value="<?php echo e($dat[0]->direccion); ?>">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Telefono</label>
      <input type="text" class="form-control" id="inputPassword4" name="telf"  value="<?php echo e($dat[0]->telefono); ?>">
    </div>
  </div>
   <!---fechas -->
   <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputfechan">Fecha de nacimiento</label>
      <input type="date" class="form-control" id="inputfechan" readonly="readonly" value="<?php echo e($dat[0]->fecna); ?>">
    </div>
    <div class="form-group col-md-6">
      <label for="inputfechanv">Fecha de ingreso a la empresa</label>
      <input type="date" class="form-control" id="inputfechanv"  readonly="readonly" value="<?php echo e($dat[0]->fecingreso); ?>">
    </div>
  </div>
  <!--- end fechas-->
  <div class="form-row">
   <div class="form-group col-md-6">
    <label for="inputAddress">Email</label>
    <input type="email" class="form-control" id="inputAddress" name="correo"  value="<?php echo e($dat[0]->email); ?>">
    </div>
    <div class="form-group col-md-6">
    <label for="inputAddress">Contraseña</label>
    <input type="password" class="form-control" id="inputAddress" name="pass" placeholder="***************">
    </div>
</div>
  <div class="form-row">
    <div class="form-group col-md-6">
        <div class="form-group">
           <label for="exampleFormControlSelect1">Seleccionar Cargo</label>
             <select class="form-control" id="cargo" name="cargo">
              <option value="<?php echo e($dat[0]->idcar); ?>" selected><?php echo e($dat[0]->nombre); ?></option>
              <?php $__currentLoopData = $cargo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c->id); ?>"><?php echo e($c->nombre); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </select>
        </div>
    </div>
    <div class="form-group col-md-4">
    <div class="form-group">
           <label for="exampleFormControlSelect1">Seleccionar Area</label>
             <select class="form-control" id="area" name="area">
              <option value="<?php echo e($dat[0]->idar); ?>" selected><?php echo e($dat[0]->nomarea); ?></option>
              <?php $__currentLoopData = $area; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($a->id); ?>"><?php echo e($a->nombre); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </select>
        </div>
    </div>
    <div class="form-group col-md-2">
    <div class="form-group">
           <label for="exampleFormControlSelect1">Seleccionar Rol</label>
             <select class="form-control" id="rol"  name="rol">
              <option value="<?php echo e($dat[0]->idrol); ?>" selected><?php echo e($dat[0]->descripcion); ?></option>
              <?php $__currentLoopData = $rol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($r->id); ?>"><?php echo e($r->descripcion); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </select>
        </div>
    </div>
  </div>
  <div class="row">
      <div class="col-md-12 modal-footer justify-content-between">
      <input type="text" class="form-control" id="inputCity" name="id"   value="<?php echo e($dat[0]->idusu); ?>" hidden>
        
        <a type="button" href="/reporte/usuarios" class="btn btn-default salir">Volver</a>
        <button type="submit" class="btn btn-success confirmar">Actualizar</button>
      </div>
      <div class="col-md-6">
        
      </div>
  </div>
</form>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('usuario.principa_usul', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Evolucion_reconoser_024\resources\views/admin/actusu.blade.php ENDPATH**/ ?>