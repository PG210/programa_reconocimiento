 <?php $__env->startSection('content'); ?>
  <?php echo $__env->make('usuario.datatables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container">
    <div class="row mb-2">
      <div class="col-sm-8">
      <h1 class="m-0">Control votaciones</h1>
      </div>
      <!-- /.col -->
      <div class="col-sm-4">
      <ol class="breadcrumb float-sm-right">
        <li class="breadcrumb-item"><a href="#">Inicio</a></li>
        <li class="breadcrumb-item active">Control votaciones</li>
      </ol>
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->
  <div class="container">

    <div class="row">
    <div class="col-12">
      <!-- Acciones Rápidas del Administrador -->
      <div class="card p-4 mb-2">
      <h4 class="card-title mb-2" style="color: #716f6e;font-size: 1.5rem;font-weight: 600;">Acciones rapidas</h4>

      <div class="row">
        <div class="col-md-3">
        <div class="">
          <!--button-->
      <?php if(isset($es[0])): ?> 
         <?php if($es[0]->estado == 2): ?>
          <button type="button" class="btn btn-success w-100 mb-2" data-toggle="modal"
          data-target="#staticBackdrop">
          ✅ Habilitar
          </button>
          <!-- Button trigger modal -->
          <!-- Modal -->
          <form action="<?php echo e(route('hab_votaciones')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1"
          aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header" style="background-color:#1ED5F4;">
            <h5 class="modal-title" id="staticBackdropLabel">Configuración de Votaciones</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
            <p>¿Seguro que quieres desactivar las votaciones?</p>
            <p>⚠️ Esto detendrá la participación del equipo en este periodo. Puedes reactivarlas en
            cualquier momento.</p>
            <div class="row">
            <div class="col-6">
            <label>Año</label>
            <input id="anio" name="anio" class="form-control" value="<?php echo e($anio); ?>" readonly="readonly"
            style="background-color:white;">
            </div>
            <div class="col-6">
            <label>Periodo</label>
            <select class="custom-select" id="per" name="per">
            <option selected>Elegir...</option>
            <option value="A">A</option>
            <option value="B">B</option>
            </select>
            <input id="val" name="val" class="form-control" value="1" hidden>
            </div>
            </div>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-default salir" data-dismiss="modal">Salir</button>
            <button type="submit" class="btn btn-primary confirmar">Deshabilitar</button>
            </div>
          </div>
          </div>
          </div>
          </form>
        <?php endif; ?> 
      <?php endif; ?> 
      <?php if($total == 0): ?>
      <button type="button" class="btn btn-success w-100 mb-2" data-toggle="modal"
      data-target="#staticBackdrop">
      ✅ Habilitar
      </button>
      <!-- Button trigger modal -->
      <!-- Modal -->
      <form action="<?php echo e(route('hab_votaciones')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1"
      aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header titulo">
        <h5 class="modal-title" id="staticBackdropLabel">Configuración de Votaciones</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
        </div>
        <div class="modal-body">
        <p>¿Seguro que quieres activar las votaciones?</p>
        <p>📅 Selecciona el año y el periodo para comenzar. 🚀</p>
        <div class="row">
        <div class="col-6">
        <label>Año</label>
        <input id="anio" name="anio" class="form-control" value="<?php echo e($anio); ?>" readonly="readonly">
        </div>
        <div class="col-6">
        <label>Periodo</label>
        <select class="custom-select" id="per" name="per">
          <option selected>Elegir...</option>
          <option value="A">A</option>
          <option value="B">B</option>
        </select>
        <input id="val" name="val" class="form-control" value="1" hidden>
        </div>
        </div>
        </div>
        <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default salir" data-dismiss="modal">Salir</button>
        <button type="submit" class="btn btn-success confirmar">Habilitar</button>
        </div>
      </div>
      </div>
      </div>
      </form>
    <?php endif; ?>
          <!--end modal-->
      <?php if(isset($es[0]->estado) == 1): ?>
        <button type="button" class="btn btn-danger w-100 mb-2 d-none d-sm-none d-md-block" data-toggle="modal"
        data-target="#staticBackdropvot1">
        ❌ Deshabilitar
        </button>
        <button type="button" class="btn btn-danger w-100 mb-2 d-block d-sm-block d-md-none" data-toggle="modal"
        data-target="#staticBackdropvot1">
        Deshabilitar
        </button>
        <!-- Modal -->
        <div class="modal fade" id="staticBackdropvot1" data-backdrop="static" data-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header titulo">
          <h5 class="modal-title" id="staticBackdropLabel">Deshabilitar Votaciones</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          ¿Desea deshabilitar las votaciones <?php echo e($es[0]->anio); ?> <?php echo e($es[0]->periodo); ?>?
        </div>
        <div class="modal-footer">
          <a href="/deshab/votacion/<?php echo e($es[0]->ides); ?>/2" type="button" class="btn confirmar">Si</a>
          <button type="button" class="btn salir" data-dismiss="modal">No</button>
        </div>
        </div>
        </div>
        </div>
        <!--end modal-->
      <?php endif; ?>
        </div>
        <p class="small m-0 text-center">Activa o desactiva según lo que necesites.</p>
        </div>
        <div class="col-md-3">
        <!-- Button trigger modal -->
        <button type="button" class="btn btn-primary w-100 mb-2" data-toggle="modal" data-target="#filtrarcat">
          🏆 Filtrar por Categoría
        </button>
        <!--end buton-->
        <p class="small m-0 text-center">Descubre la categoria por periodos.</p>
        </div>
        <div class="col-md-3">
        <button type="button" class="btn btn-success w-100 mb-2" data-toggle="modal" data-target="#filtrarvotos">
          🔍 Filtrar por Votos
        </button>
        <p class="small m-0 text-center">Descubre los votos por periodos.</p>
        </div>
        <div class="col-md-3">
        <!--generar excel de los datos -->
        <button type="button" class="btn btn-warning w-100 mb-2" data-toggle="modal" data-target="#excel">
          📁 Generar Reportes
        </button>
        <p class="small m-0 text-center">Descargar datos clave en Excel/PDF.</p>
        </div>
      </div>
      </div>
      <!-- Modales -->
      <div class="">
      <!--modal para reportes de excel-->
      <div class="modal fade" id="excel" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header titulo">
          <h5 class="modal-title" id="exampleModalLabel">Generar reportes de votación</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
          </div>
          <form action="<?php echo e(route('excelVotos')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="modal-body letraform">
            <!---inputs-->
            <div class="row">
            <p>📌 Selecciona el año, periodo y estado de votación para generar el informe con el total de votos
              recibidos. 🚀</p>
            <div class="col-6">
              <div class="form-group">
              <label for="exampleFormControlSelect1">Año</label>
              <select class="form-control" id="aniovot" name="aniovot">
                <?php $__currentLoopData = $esfil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if(isset($fil->anio)): ?>
                    <option val="<?php echo e($fil->anio); ?>"><?php echo e($fil->anio); ?></option>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              </div>
            </div>
            <div class="col-6">
              <div class="form-group">
              <label for="exampleFormControlSelect1">Periodo</label>
              <select class="form-control" id="pervot" name="pervot">
                <option value="A">A</option>
                <option value="B">B</option>
              </select>
              </div>
            </div>
            </div>
            <!--seleccion-->
            <div class="row">
            <div class="col-12">
              <div class="form-group">
              <label for="usuarios">Seleccionar estado de votación</label>
              <select class="form-control" id="usuarios" name="usuarios">
                <option value="1">Total de votos recibidos</option>
                <option value="2">Usuarios que han votado</option>
                <option value="3">Usuarios que no han votado</option>
              </select>
              </div>
            </div>
            </div>
            <!--end inputs-->
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default salir" data-dismiss="modal">Salir</button>
            <button type="submit" class="btn btn-success confirmar"><i
              class="fas fa-download"></i>&nbsp;Descargar</button>

          </div>
          </form>
        </div>
        </div>
      </div>
      <!--- end reporte-->
      <form action="<?php echo e(route('filtrarVotos')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <!-- Modal -->
        <div class="modal fade" id="filtrarvotos" tabindex="-1" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
          <div class="modal-header titulo">
            <h5 class="modal-title" id="exampleModalLabel">Seleccionar Año y Periodo</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body letraform">
            <!---inputs-->
            <div class="row">
            <p>📌 Elige el periodo que deseas analizar y accede a la información relevante.</p>
            <div class="col-6">
              <div class="form-group">
              <label for="exampleFormControlSelect1">Año</label>
              <select class="form-control" id="aniofil" name="aniofil">
                <?php $__currentLoopData = $esfil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(isset($fil->anio)): ?>
                      <option val="<?php echo e($fil->anio); ?>"><?php echo e($fil->anio); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              </div>
            </div>
            <div class="col-6">
              <div class="form-group">
              <label for="exampleFormControlSelect1">Periodo</label>
              <select class="form-control" id="peri" name="peri">
                <option value="A">A</option>
                <option value="B">B</option>
              </select>
              </div>
            </div>
            </div>
            <!--end inputs-->
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default salir" data-dismiss="modal">Salir</button>
            <?php if(isset($esfil[0]->anio)): ?>
        <button type="submit" class="btn btn-success confirmar"><i class="fas fa-search"></i> Filtrar</button>
      <?php endif; ?>
          </div>
          </div>
        </div>
        </div>
      </form>
      <!--end filtrar-->
      <!--filtrar por categoria-->
      <!-- Button trigger modal -->
      <!-- Modal -->
      <form action="<?php echo e(route('listaVot')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="filtrarcat" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
          <div class="modal-header titulo">
            <h5 class="modal-title" id="exampleModalLabel">Filtrar Votos Por Categoria</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body letraform">
            <!--mostrar categorias-->
            <div class="row">
            <div class="col-12">
              <p>📌 Selecciona la categoría, año y periodo para obtener los resultados que necesitas. </p>
              <div class="form-group">
              <label for="categoria">Categoria</label>
              <select class="form-control" id="categoria" name="categoria">
                <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if(isset($c->descripcion)): ?>
                    <option value="<?php echo e($c->idcat); ?>"><?php echo e($c->descripcion); ?></option>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              </div>
            </div>
            </div>

            <div class="row">
            <div class="col-6">
              <div class="form-group">
              <label for="exampleFormControlSelect1">Año</label>
              <select class="form-control" id="anio" name="anio">

                <?php $__currentLoopData = $esfil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if(isset($fil->anio)): ?>
                    <option val="<?php echo e($fil->anio); ?>"><?php echo e($fil->anio); ?></option>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              </div>
            </div>
            <div class="col-6">
              <div class="form-group">
              <label for="exampleFormControlSelect1">Periodo</label>
              <select class="form-control" id="per" name="per">
                <option value="A">A</option>
                <option value="B">B</option>
              </select>
              </div>
            </div>
            </div>
            <!--end categorias-->
          </div>

          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default" data-dismiss="modal">Salir</button>
            <?php if(isset($esfil[0]->anio)): ?>
              <button type="submit" class="btn btn-success"><i class="fas fa-search"></i> Filtrar</button> 
            <?php endif; ?>
          </div>
          </div>
        </div>
        </div>
      </form>
      <!--end filtrar por categoria-->
      </div>
    </div>
    </div>

  <!-- errores -->
  <?php if(Session::has('mensajeEx')): ?>
    <div class="col-12 letraform">
      <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong> <?php echo e(Session::get('mensajeEx')); ?></strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
      </div>
    </div>
  <?php endif; ?>

  <?php if(Session::has('errorhab')): ?>
    <div id="toastsContainerTopRight" class="toasts-top-right fixed">
      <div class="toast bg-warning fade show " role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header px-2 py-4">
          <i class="mr-2 fas fa-x fa-lg"></i>
          <strong class="mr-auto"><?php echo e(Session::get('errorhab')); ?></strong>
          <small></small>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">×</span>
          </button>
        </div>
      </div>
    </div>
  <?php endif; ?>
  <?php if(Session::has('errorfitrar')): ?>
    <div id="toastsContainerTopRight" class="toasts-top-right fixed">
      <div class="toast bg-warning fade show " role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header px-2 py-4">
          <i class="mr-2 fas fa-x fa-lg"></i>
          <strong class="mr-auto"><?php echo e(Session::get('errorfitrar')); ?></strong>
            <small></small>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
            </button>
          </div>
      </div>
    </div>
  <?php endif; ?>

    <div class="row mb-2">
    <div class="col-12">

      <!---Aqui generar los usuarios que han votado -->
      <h5 class="letraform mb-2">Postular Colaboradores</h5>
      <div class="card">

      <!-- /.card-header -->
      <div class="px-3 mb-2 mt-5">
        <form action="<?php echo e(route('postularVot')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="table-responsive">
          <table class="table table-hover table-estadisticas" id="votacion01">
          <thead>
            <tr>
            <th scope="col">No</th>
            <th scope="col">Nombres</th>
            <th scope="col">Cargo</th>
            <th scope="col">
              <div class="text-center">
                <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#modalPostular">
                <i class="fas fa-hand-pointer"></i> Postular
                </button>
              </div>
            </th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <th scope="row"><?php echo e($loop->iteration); ?></th>
                <td><?php echo e($usu->name); ?> <?php echo e($usu->apellido); ?></td>
                <td><?php echo e($usu->cargo); ?></td>
                <td>
                  <div class=" text-center">
                  <input class="" type="checkbox" value="<?php echo e($usu->idusu); ?>" id="defaultCheck1<?php echo e($usu->idusu); ?>"
                  name="user[]" <?php if($usu->postulado == '1'): ?> checked <?php endif; ?>>
                  </div>
                </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          </table>
        </div>
        <!-- Modal confirmar postulacion -->
        <div class="modal fade" id="modalPostular" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Mensaje de confirmación</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body text-left">
                  <p>
                    ¿Estás seguro de que deseas postular a los colaboradores seleccionados?
                  </p>
                  </div>
                  <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Salir</button>
                    <button type="submit" class="btn btn-success">Confirmar</button>
                  </div>
                </div>
            </div>
        </div>
        <!---end modal-->
        </form>
        <!--end votos-->
      </div>


      </div>
      <!-- /.card-body -->



    </div>
    <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  <script>
    $('#votacion01').DataTable({
    "language": {
      "url": "https://cdn.datatables.net/plug-ins/1.10.24/i18n/Spanish.json"
    },
    });
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('usuario.principa_usul', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Evolucion_reconoser_024\resources\views/admin/votaciones.blade.php ENDPATH**/ ?>