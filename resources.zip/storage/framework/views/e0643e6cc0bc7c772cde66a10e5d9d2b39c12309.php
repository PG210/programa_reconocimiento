
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('usuario.datatables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 

  <!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container">
    <div class="row mb-2">
      <div class="col-sm-9">
       <h1 class="m-0">Reconocimientos que Has Enviado</h1>
       <p>Cada reconocimiento fortalece el equipo. ¡Sigue motivando a tus compañeros! </p>
      </div>
      <!-- /.col -->
      <div class="col-sm-3">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Inicio</a></li>
          <li class="breadcrumb-item active">Reconocimientos enviados</li>
        </ol>
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  <div class="container">
    <div class="row">
    <div class="col-12">
      <div class="card">
      <div class="card-body">
        <div class="row">
        <div class="col-md-8">
          <p class="text-center">
          <strong>🌟 Has enviado
            <?php if(isset($totmes->total)): ?>
              <?php echo e($totmes->total ?? 0); ?>

            <?php endif; ?>
            reconocimientos este mes </strong>
          </p>
           <?php if( count($recenvia) > 0): ?>
            <div class="chart-container" style="height: 180px; width:100%;">
             <canvas id="timelineChart"></canvas>
            </div>
           <?php endif; ?>
          <!-- /.chart-responsive -->
        </div>
        <!-- /.col -->
        <div class="col-md-4">
          <p class="text-center">
          <strong>Categorias</strong>
          </p>

          <?php if(isset($puntoscat)): ?>
              <?php
                  // Array de clases de colores para la progress bar
                  $colores = ['bg-warning', 'bg-info', 'bg-danger', 'bg-success', 'bg-secondary'];
                  $index = 0; // Para iterar sobre los colores
              ?>

              <?php $__currentLoopData = $puntoscat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="progress-group">
                  <?php echo e($pc->nomcat); ?>

                  <span class="float-right"><b><?php echo e($pc->puntos); ?></b>/1000</span>
                  <div class="progress progress-sm">
                    <div class="progress-bar <?php echo e($colores[$index]); ?>" style="width: <?php echo e(($pc->puntos * 100) / 1000); ?>%">
                    </div>
                  </div>
                </div>
                <?php
                // Incrementamos el índice y lo reiniciamos si llega al final del array
                $index = ($index + 1) % count($colores);
                ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php endif; ?>
          <!-- /.progress-group -->

        </div>
        <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>

      </div>
      <div class="card">
      <!-- /.card-header -->
      <div class="card-header mt-2">
        <div class="table-responsive">
        <table class="table table-hover table-estadisticas" id="tabla2">
          <thead class="tablaheader">
          <tr>
            <th scope="col">No</th>
            <th scope="col">Nombres</th>
            <th scope="col">Categoría</th>
            <th scope="col">Detalle</th>
            <th scope="col">Peñutes</th>
          </tr>
          </thead>
          <tbody>
          <?php
           $conta = 1;
          ?>
          <?php if(count($agrupados) != 0): ?>
                <?php $__currentLoopData = $agrupados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iduser => $registros): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   
                
                <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($conta++); ?> </td>
                    <td><?php echo e($registros->first()->name); ?> <?php echo e($registros->first()->apellido); ?></td>
                    <td><?php echo e($info->cate); ?></td>
                    <td><?php echo e($info->detalle); ?></td>
                    <td><?php echo e($info->puntaje); ?></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
      </tbody>
  </table>
<!--====================-->
  </div>
  </div>
      <!-- /.card-body -->
  </div>

  </div>
  </div>
</div>
<!------###########################-->

<script>
    window.rectime = <?php echo json_encode($recenvia, 15, 512) ?>;

    $('#tabla2').DataTable({
    "language": {
      "url": "https://cdn.datatables.net/plug-ins/1.10.24/i18n/Spanish.json"
    },
    });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('usuario.principa_usul', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Evolucion_reconoser_024\resources\views/metricas/recenviados.blade.php ENDPATH**/ ?>