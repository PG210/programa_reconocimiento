
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('usuario.datatables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
 <div class="container"> 
  <div class="row mb-2">
   <div class="col-sm-8">
    <h1 class="m-0">Registros de recompensas</h1>
   </div>
   <!-- /.col -->
   <div class="col-sm-4">
    <ol class="breadcrumb float-sm-right">
     <li class="breadcrumb-item"><a href="#">Inicio</a></li>
     <li class="breadcrumb-item active">Registros de recompensas</li>
    </ol>
   </div>
   <!-- /.col -->
  </div>
  <!-- /.row -->
 </div>
 <!-- /.container-fluid -->
</div>
<!-- /.content-header -->
<div class="container">
<div class="row mb-2">
  <div class="col-12">
  <div class="card">

                    
<?php if(Session::has('eliminarexit')): ?>
<div class="alert alert-warning alert-dismissible fade show letraform mb-2" role="alert">
  <strong><?php echo e(Session::get('eliminarexit')); ?></strong> 
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<br>
<?php endif; ?>

<?php if(Session::has('actualizadopre')): ?>
<div class="alert alert-warning alert-dismissible fade show letraform mb-2" role="alert">
  <strong><?php echo e(Session::get('actualizadopre')); ?></strong> 
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<br>
<?php endif; ?>

<!--Modal visualizar imagenes-->
<div class="card-header">
    <div class="btn-group" role="group" aria-label="Basic outlined example">
      <button type="button" class="btn btn-warning confirmar letraform" data-toggle="modal" data-target="#visualizar">Agregar</button>
    </div>
</div>
   <!-- /.card-header -->
    <div class="px-3">
                        
      <div class="table-responsive mt-3 mb-3">
         <table class="table table-hover table-estadisticas" id="table02">
              <thead class="tablaheader">
              <tr>
                <th scope="col">No</th>
                <th scope="col">Nombre</th>
                <th scope="col">Descripción</th>
                <th scope="col">Imagen</th>
                <th scope="col" class="text-center" style="width: 100px;">Acciones</th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $dat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th scope="row"><?php echo e($c->id); ?></th>
                  <td><?php echo e($c->name); ?></td>
                  <td><?php echo e($c->descripcion); ?></td>
                  <td>
                    <div class="text-center">
                    <img src="<?php echo e(asset('imgpremios/'.$c->rutaimagen)); ?>" class="rounded" alt="..."  width= "50px" height="50px" >
                  </div>
                 </td>
                 <td>
                  <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                    <button  type="button" class="btn btn-outline-primary btn-sm" data-toggle="modal" data-target="#editar<?php echo e($c->id); ?>"><i class="fas fa-edit"></i></button>
            
                    <button type="button" class="btn btn-outline-danger btn-sm" data-toggle="modal" data-target="#eliminarPre<?php echo e($c->id); ?>">
                      <i class="fas fa-trash-alt"></i>
                    </button>
                  </div>
                    <!-- Modal registrar insignias -->
                    <div class="modal fade" id="editar<?php echo e($c->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog modal-dialog-scrollable modal-lg">
                        <div class="modal-content ">
                          <div class="modal-header">
                            <h5 class="modal-title titulo" id="exampleModalLabel">Actualización recompensas</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <form action="<?php echo e(route('regpremioactu')); ?>" method="POST" class="letraform"  enctype="multipart/form-data">
                              <?php echo csrf_field(); ?>
                            <!-- Content Header (Page header) -->
                            <div class="modal-body">
                              <div class="form-row">
                                <div class="form-group col-md-6">
                                  <label for="nombre">Nombre</label>
                                  <input type="text" class="form-control" id="nombreupdate<?php echo e($c->id); ?>" name="nombreupdate" value="<?php echo e($c->name); ?>" required>
                                  <input type="hidden" value="<?php echo e($c->id); ?>" name="idupdate" id="idupdate<?php echo e($c->id); ?>">
                                </div>
                                <div class="form-group col-md-6">
                                  <label for="des">Descripción</label>
                                  <input type="text" class="form-control" id="desupdate<?php echo e($c->id); ?>" name="desupdate"  value="<?php echo e($c->descripcion); ?>" required>
                                </div>
                              </div>
                              <div class="form-group">
                                <label for="exampleFormControlFile1">Seleccionar Imagen</label>
                                <input type="file" class="form-control-file form-control" id="imgupdate<?php echo e($c->id); ?>" name="imgupdate">
                              </div>
                            </div>
                            <div class="modal-footer justify-content-between ">
                              <button type="button" class="btn btn-default salir" data-dismiss="modal">Salir</button>
                              <button type="submit" class="btn btn-success #confirmar">Actualizar</button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                    <!---end modal-->
                    <!---modal para confirmar eliminar -->
                    <div class="modal fade" id="eliminarPre<?php echo e($c->id); ?>" tabindex="-1"
                      aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Mensaje de confirmación</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body text-left">
                              <p>
                                ¿Seguro que quieres eliminar el premio "<?php echo e($c->name); ?>"?
                              </p>
                              </div>
                              <div class="modal-footer justify-content-between">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                                <form action="<?php echo e(route('eliminarpremio')); ?>" method="POST">
                                  <?php echo csrf_field(); ?>
                                  <input type="hidden" name="idpre" id="idpre<?php echo e($c->id); ?>" value="<?php echo e($c->id); ?>">
                                  <button type="submit" class="btn btn-success">Eliminar</button>
                                </form>
                              </div>
                            </div>
                        </div>
                    </div>
                  <!--end modal confirmar-->
                </td>
                </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
    </div>
<!--end tabla-->
</div>     

<!-- Modal registrar recompensas -->
<div class="modal fade" id="visualizar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable modal-lg">
    <div class="modal-content ">
      <div class="modal-header">
        <h5 class="modal-title titulo" id="exampleModalLabel">Registrar Nueva Recompensa</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(route('regpremio')); ?>" method="POST" class="letraform"  enctype="multipart/form-data">
      <div class="modal-body letraform">
        <p>¡Dale un incentivo especial a tus colaboradores!</p>
        <!--==========================--->
          <?php echo csrf_field(); ?>
          <div class="form-row">
            <div class="form-group col-md-12">
              <label for="nombre">Nombre</label>
              <p>Ingresa el nombre de la recompensa.</p>
              <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Ingrese nombre" required>
            </div>
            <div class="form-group col-md-12">
              <label for="des">Descripción</label>
              <p>Explica brevemente en qué consiste.</p>
              <textarea class="form-control" id="des" name="des" placeholder="Detalle" required rows="2"></textarea>
            </div>
          </div>
          <div class="form-group">
            <label for="exampleFormControlFile1">Seleccionar Imagen</label>
            <p>Sube una imagen representativa para esta recompensa.</p>
            <input type="file" class="form-control-file form-control" id="img" name="img" required>
          </div>      
        <!---===========================-->
      </div>
      <div class="modal-footer justify-content-between ">
        <button type="button" class="btn btn-default salir" data-dismiss="modal">Salir</button>
        <button type="submit" class="btn btn-success confirmar">Registrar</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!---end modal-->
</div>
  </div>
</div>
</div>

<script>
  $('#table02').DataTable({
    "language": {
      "url": "https://cdn.datatables.net/plug-ins/1.10.24/i18n/Spanish.json"
    },
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('usuario.principa_usul', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Evolucion_reconoser_024\resources\views/insignias/premios.blade.php ENDPATH**/ ?>