@extends('principal')
@section('content')
<!--informacion de contactos-->
<div style="background-image:url('images/demo/01.jpg');">
  <main class="hoc container clear" > 
    <div class="overlay"> 
    <br><br>
    <h1 style="font-size:5rem; text-align:center;">Contáctanos</h1>
    <br>
    <p style="text-align: center;font-size:1.5rem;">Ayudamos a solucionar de manera creativa, divertida y constructivista los retos de aprendizaje en las empresas.</p>
    <br><br>
  </div>
  </main>
</div>
@endsection