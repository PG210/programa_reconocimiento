<!--<link href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@200;500;700&display=swap" rel="stylesheet">
<style>
  .letra1{
       font-family: 'Roboto Slab', serif;
       font-size:17px;
       line-height: 1.3;
       font-weight: 200;
       text-align:center; 
  }
  .letra2{
       font-family: 'Roboto Slab', serif;
       font-size:16px;
       line-height: 1.5;
       font-weight: 200;
       text-align:left;
  }
  .letra_peq{
       font-family: 'Roboto Slab', serif;
       font-size:16px;
       line-height: 1.3;
       font-weight: 200;
       text-align:left; 
  }
  .letraform{
       font-family: 'Roboto Slab', serif;
       font-size:17px;
       line-height: 1.3;
       font-weight: 500;
       text-align:left; 
  }

  .titulo{
       font-family: 'Roboto Slab', serif;
       font-size:20px;
       line-height: 1.3;
       font-weight: 500;
       text-align:center; 
  }

  .confirmar{
     background-color:#17a2b8;
     color:#FFFFFF;
  }

  .ver{
     background-color:#28a745;
     color:#FFFFFF;
  }

  .salir{
     background-color:#FFBD03;
     color:#FFFFFF;
  }

  .botonmorado{
     background-color:#5959D1;
     color:#FFFFFF;
  }
  .tablaheader{
     background-color:#F2C93B;
     color:#000;
  }
  .letratarjeta1{
       font-family: 'Roboto Slab', serif;
       font-size: 20px;
       line-height: 1.3;
       font-weight: 400;
  }

  .letratarjeta2{
       font-family: 'Roboto Slab', serif;
       font-size: 24px;
       line-height: 1.3;
       font-weight: 400;
  }

  .letratarjeta3{
       font-family: 'Roboto Slab', serif;
       font-size: 18px;
       line-height: 1.3;
       font-weight: 400;
  }
 .letraform2{
       font-family: 'Roboto Slab', serif;
       font-size: 16px;
       line-height: 1.3;
       font-weight: 400;
       color:black;
 }
 .colortablas{
     background-color: #F2C93B;
 }
</style> -->