<?php

namespace App\Models\Insignias;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InsigniasModel extends Model
{
    protected $table = 'insignia';
    protected $primaryKey = 'id';//tiene que hacer referencia a la llave primaria  
}
