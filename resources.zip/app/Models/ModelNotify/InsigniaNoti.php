<?php

namespace App\Models\ModelNotify;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InsigniaNoti extends Model
{
    protected $table = 'noti_insignia';
    protected $primaryKey = 'id';
}
