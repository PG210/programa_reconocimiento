<?php

namespace App\Models\Reconocimientos;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ReconocimientosController extends Model
{
    use HasFactory;
}
