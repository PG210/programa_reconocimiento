<?php

namespace App\Models\Reconocimientos;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ReconocimientosModal extends Model
{
    protected $table = 'insignia_obtenida';
    protected $primaryKey = 'id';
}
