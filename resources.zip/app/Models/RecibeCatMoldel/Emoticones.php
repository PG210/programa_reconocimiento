<?php

namespace App\Models\RecibeCatMoldel;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Emoticones extends Model
{
    protected $table = 'emoticones';
    protected $primaryKey = 'id';
}